# Omschrijving van de repository (project);

Voor het vak PGM-1 maak ik een Node.js applicatie waarin de lineup wordt getoond van Rock Werchter 2022. De lineup bestaat uit een lijst van concerten.

# Oplijsting van aanwezige bestanden en folders;

- pgm-1_opdracht_1_de_niel_jef
  - rockwerchter_app
    - .gitignore
    - app
      - index.js
    - LICENCE
    - README.md
  - rockwerchter_docs
    - screenshots
      \*code_snippets

# Configuratie en installatie instructies;

volgt nog

# Documentatie;

volgt nog

# Gekende bugs;

volgt nog

# Aanvragen voor toekomstige nieuwe features;

volgt nog

# Auteurs;

Jef De Niel

# Copyright en licentie.

Arteveldehogeschool
